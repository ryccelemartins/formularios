<?php
// Habilitar exibição de erros para debug (remover em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../vendor/autoload.php'; // Carrega o PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Coletar dados do formulário
    $data_do_culto = $_POST['data_do_culto'] ?? '';
    $tema_versiculo_biblico = $_POST['tema_versiculo_biblico'] ?? '';
    $ministerio_responsavel = $_POST['ministerio_responsavel'] ?? '';
    $nome_do_responsavel = $_POST['nome_do_responsavel'] ?? '';
    $data_e_horario = $_POST['data_e_horario'] ?? '';
    $local = $_POST['local'] ?? '';
    $observacao = $_POST['observacao'] ?? '';

    // Verificar se os campos obrigatórios estão preenchidos
    if (empty($data_do_culto) || empty($nome_do_responsavel)) {
        die("Erro: Data do culto e nome do responsável são obrigatórios.");
    }

    // Configuração do PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'martins.ryccele@gmail.com'; // Substitua pelo seu e-mail do Gmail
        $mail->Password = 'mltd yibo qxwm lcdh'; // Substitua pela senha do aplicativo
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Assunto e nome dinâmicos
        $emailAssunto = "$nome_do_responsavel - $data_do_culto";

        // Configuração de remetente e destinatário
        $mail->setFrom('martins.ryccele@gmail.com', $emailAssunto); // Nome dinâmico no remetente
        $mail->addAddress('deislainedarling@creativemedia.com.br', 'Deislaine Darling');

        // Definir charset
        $mail->CharSet = 'UTF-8';

        // Assunto do e-mail
        $mail->Subject = $emailAssunto;

        // Corpo do e-mail
        $mail->isHTML(true);
        $mail->Body = "
            <h2>Nome do Responsável: $nome_do_responsavel</h2>
            <h2>Data do Culto: $data_do_culto</h2>
            <p><strong>Tema/Versículo Bíblico:</strong> $tema_versiculo_biblico</p>
            <p><strong>Ministério Responsável:</strong> $ministerio_responsavel</p>
            <p><strong>Data e Horário:</strong> $data_e_horario</p>
            <p><strong>Local:</strong> $local</p>
            <p><strong>Observações:</strong> $observacao</p>
        ";

        // Processar uploads de arquivos
        if (!empty($_FILES['arquivo_referencia']['name'][0])) {
            foreach ($_FILES['arquivo_referencia']['tmp_name'] as $index => $tmpName) {
                if (is_uploaded_file($tmpName)) {
                    $fileName = $_FILES['arquivo_referencia']['name'][$index];

                    // Validar tamanho do arquivo (limite de 5MB)
                    if ($_FILES['arquivo_referencia']['size'][$index] <= 5 * 1024 * 1024) { // 5 MB
                        $mail->addAttachment($tmpName, $fileName); // Adicionar arquivo como anexo
                    } else {
                        echo "<script>alert('O arquivo $fileName excede o tamanho máximo de 200MB e não foi enviado.');</script>";
                    }
                }
            }
        }

        // Enviar e-mail
        $mail->send();

        // Exibe a mensagem de sucesso e redireciona de volta para o formulário vazio
        echo "<script>
                alert('Formulário enviado com sucesso! O Material ficará disponível em até 10 dias úteis.');
                window.location.href = '/formulario/artes_cultos/index.html'; // Redireciona de volta ao formulário
              </script>";
    } catch (Exception $e) {
        echo "<script>
                alert('Erro ao enviar o formulário: {$mail->ErrorInfo}');
                window.location.href = '/formulario/artes_cultos/index.html'; // Redireciona de volta ao formulário
              </script>";
    }
}
?>

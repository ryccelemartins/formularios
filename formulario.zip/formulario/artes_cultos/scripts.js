document.addEventListener('DOMContentLoaded', function() {
    const livroSelect = document.getElementById('livro');
    const capituloSelect = document.getElementById('capitulo');
    const versiculoSelect = document.getElementById('versiculo');
    const versiculoTexto = document.getElementById('versiculo_texto');

    // Função para carregar os capítulos quando o livro é selecionado
    livroSelect.addEventListener('change', function() {
        const livro = this.value;
        if (livro) {
            capituloSelect.disabled = false;
            capituloSelect.innerHTML = ''; // Limpa os capítulos anteriores
            for (let i = 1; i <= 50; i++) {  // Exemplo: carregar até 50 capítulos (ajuste conforme o livro)
                const option = document.createElement('option');
                option.value = i;
                option.textContent = `Capítulo ${i}`;
                capituloSelect.appendChild(option);
            }
        } else {
            capituloSelect.disabled = true;
            versiculoSelect.disabled = true;
            capituloSelect.innerHTML = '';
            versiculoSelect.innerHTML = '';
        }
    });

    // Função para carregar versículos quando o capítulo é selecionado
    capituloSelect.addEventListener('change', function() {
        const livro = livroSelect.value;
        const capitulo = this.value;
        if (capitulo) {
            versiculoSelect.disabled = false;
            versiculoSelect.innerHTML = ''; // Limpa os versículos anteriores
            for (let i = 1; i <= 50; i++) { // Exemplo: carregar até 50 versículos (ajuste conforme o capítulo)
                const option = document.createElement('option');
                option.value = i;
                option.textContent = `Versículo ${i}`;
                versiculoSelect.appendChild(option);
            }
        } else {
            versiculoSelect.disabled = true;
            versiculoSelect.innerHTML = '';
        }
    });

    // Função para buscar o texto do versículo quando selecionado
    versiculoSelect.addEventListener('change', function() {
        const livro = livroSelect.value;
        const capitulo = capituloSelect.value;
        const versiculo = this.value;
        if (versiculo) {
            const url = `https://bible-api.com/${livro}+${capitulo}:${versiculo}`;
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    versiculoTexto.value = data.text;
                })
                .catch(error => console.error('Erro ao carregar o versículo:', error));
        }
    });
});

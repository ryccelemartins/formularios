<?php
// Ativar exibição de erros para depuração (remover em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../vendor/autoload.php'; // Carregar o PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Coletar dados do formulário
    $nome_do_curso = $_POST['nome_do_curso'] ?? '';
    $tema_versiculo_biblico = $_POST['tema_versiculo_biblico'] ?? '';
    $ministerio_responsavel = $_POST['ministerio_responsavel'] ?? '';
    $nome_do_responsavel = $_POST['nome_do_responsavel'] ?? '';
    $data_inicio = $_POST['data_inicio'] ?? '';
    $local = $_POST['local'] ?? '';
    $observacao = $_POST['observacao'] ?? '';

    // Verificar se os campos obrigatórios estão preenchidos
    if (empty($nome_do_curso) || empty($nome_do_responsavel)) {
        die("Erro: Nome do curso e nome do responsável são obrigatórios.");
    }

    // Configuração do PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'martins.ryccele@gmail.com';
        $mail->Password = 'mltd yibo qxwm lcdh'; // Substitua pela senha do aplicativo
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Assunto e nome dinâmicos
        $emailAssunto = "Solicitação de Arte - Curso: $nome_do_curso | Responsável: $nome_do_responsavel";

        // Configuração de remetente e destinatário
        $mail->setFrom('martins.ryccele@gmail.com', $emailAssunto);
        $mail->addAddress('deislainedarling@creativemedia.com.br', 'Deislaine Darling');

        // Definir charset
        $mail->CharSet = 'UTF-8';

        // Assunto do e-mail
        $mail->Subject = $emailAssunto;

        // Corpo do e-mail
        $mail->isHTML(true);
        $mail->Body = "
            <h2>Nome do Solicitante - $nome_do_responsavel</h2>
            <h2>Nome Do Curso - $nome_do_curso</h2>
            <p><strong>Tema/Versículo Bíblico:</strong> $tema_versiculo_biblico</p>
            <p><strong>Ministério Responsável:</strong> $ministerio_responsavel</p>
            <p><strong>Data de Início:</strong> $data_inicio</p>
            <p><strong>Local:</strong> $local</p>
            <p><strong>Observações:</strong> $observacao</p>
        ";

        // Processar uploads de arquivos
        if (!empty($_FILES['arquivo_referencia']['name'][0])) {
            foreach ($_FILES['arquivo_referencia']['tmp_name'] as $index => $tmpName) {
                if (is_uploaded_file($tmpName)) {
                    $fileName = $_FILES['arquivo_referencia']['name'][$index];
                    $fileSize = $_FILES['arquivo_referencia']['size'][$index];

                    // Validar tamanho do arquivo (exemplo: 5MB máximo)
                    if ($fileSize <= 5 * 1024 * 1024) { // 5 MB
                        $mail->addAttachment($tmpName, $fileName); // Adicionar arquivo como anexo
                    } else {
                        echo "<script>alert('O arquivo $fileName excede o tamanho máximo de 200MB e não será enviado.');</script>";
                    }
                }
            }
        }

        // Enviar e-mail
        $mail->send();

        // Redirecionar para a página correta do formulário
        echo "<script>
                alert('Formulário enviado com sucesso! O material estará disponível para download em até 10 dias úteis.');
                window.location.href = '/formulario/artes_cursos/index.html';
              </script>";
    } catch (Exception $e) {
        echo "<script>
                alert('Erro ao enviar o e-mail: {$mail->ErrorInfo}');
                window.location.href = '/formulario/artes_cursos/index.html';
              </script>";
    }
} else {
    echo "Método de requisição inválido.";
}
?>

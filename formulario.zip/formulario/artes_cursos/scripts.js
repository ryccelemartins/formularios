document.addEventListener('DOMContentLoaded', function () {
    const livroSelect = document.getElementById('livro');
    const capituloSelect = document.getElementById('capitulo');
    const versiculoSelect = document.getElementById('versiculo');
    const versiculoTexto = document.getElementById('versiculo_texto');

    // Função para carregar os capítulos quando o livro é selecionado
    livroSelect.addEventListener('change', function () {
        const livro = this.value;
        capituloSelect.disabled = !livro;
        capituloSelect.innerHTML = ''; // Limpa os capítulos anteriores
        versiculoSelect.disabled = true;
        versiculoSelect.innerHTML = ''; // Limpa os versículos anteriores
        versiculoTexto.value = ''; // Limpa o texto do versículo

        if (livro) {
            for (let i = 1; i <= 50; i++) { // Exemplo: carregar até 50 capítulos
                const option = document.createElement('option');
                option.value = i;
                option.textContent = `Capítulo ${i}`;
                capituloSelect.appendChild(option);
            }
        }
    });

    // Função para carregar versículos quando o capítulo é selecionado
    capituloSelect.addEventListener('change', function () {
        const capitulo = this.value;
        versiculoSelect.disabled = !capitulo;
        versiculoSelect.innerHTML = ''; // Limpa os versículos anteriores
        versiculoTexto.value = ''; // Limpa o texto do versículo

        if (capitulo) {
            for (let i = 1; i <= 50; i++) { // Exemplo: carregar até 50 versículos
                const option = document.createElement('option');
                option.value = i;
                option.textContent = `Versículo ${i}`;
                versiculoSelect.appendChild(option);
            }
        }
    });

    // Função para buscar o texto do versículo quando selecionado
    versiculoSelect.addEventListener('change', function () {
        const livro = livroSelect.value;
        const capitulo = capituloSelect.value;
        const versiculo = this.value;
        versiculoTexto.value = ''; // Limpa o texto do versículo

        if (livro && capitulo && versiculo) {
            const url = `https://bible-api.com/${livro}+${capitulo}:${versiculo}`;
            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro na API');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.text) {
                        versiculoTexto.value = data.text;
                    } else {
                        console.error('Texto do versículo não encontrado:', data);
                        alert('Texto do versículo não encontrado.');
                    }
                })
                .catch(error => {
                    console.error('Erro ao carregar o versículo:', error);
                    alert('Ocorreu um erro ao buscar o texto do versículo.');
                });
        }
    });
});

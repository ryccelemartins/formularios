// script.js
const ministries = {
  "Gestor Financeiro": "https://cloud.batistaatos.com.br/index.php/s/fJgnSsG3qo5bod4",
  "Secretaria": "https://cloud.batistaatos.com.br/index.php/s/9crFKQ8QpPiSrYk",
  "Diáconos": "https://cloud.batistaatos.com.br/index.php/s/XxBMHPfYds9nrAx",
  "Ministério Infantil": "https://drive.google.com/ministerio-infantil",
  "Galera Teen": "https://cloud.batistaatos.com.br/index.php/s/WAWwDekF9cynbSZ",
  "Adolescentes": "https://cloud.batistaatos.com.br/index.php/s/dnSx586eqC64TZg",
  "Jovens": "https://cloud.batistaatos.com.br/index.php/s/qFf7Fn3jCe8Egng",
  "Ministério de Homens": "https://cloud.batistaatos.com.br/index.php/s/gKXnDfsrZELs7mC",
  "Mulheres": "https://cloud.batistaatos.com.br/index.php/s/zbPyx8x89LdF6E2",
  "Ministerio de Casais": "https://cloud.batistaatos.com.br/index.php/s/MwXKTewqKf5PatK",
  "Louvor": "https://cloud.batistaatos.com.br/index.php/s/9Q6ktPYtMYCSz2Y",
  "Coral": "https://cloud.batistaatos.com.br/index.php/s/XfDn8rBRbY782SG",
  "Dança": "https://cloud.batistaatos.com.br/index.php/s/2q87DMZqANLwzfP",
  "Teatro": "https://cloud.batistaatos.com.br/index.php/s/i4ToADteAgK2Ab5",
  "EBD": "https://cloud.batistaatos.com.br/index.php/s/SYgxxtfRK9dRBdQ",
  "Leitura Bíblica Anual": "https://cloud.batistaatos.com.br/index.php/s/sq8sk4gpB4MXaWb",
  "Tarde da Benção": "https://cloud.batistaatos.com.br/index.php/s/owe799rZzNXwBg6",
  "Curso De Noivos": "https://cloud.batistaatos.com.br/index.php/s/aR9bmbWPy5QfRTb",
};

const searchButton = document.getElementById("searchButton");
const searchInput = document.getElementById("searchInput");
const resultsDiv = document.getElementById("results");

const performSearch = () => {
  const searchTerm = searchInput.value.toLowerCase().trim();

  // Limpa resultados anteriores
  resultsDiv.innerHTML = "";

  // Se o campo de busca estiver vazio, lista todos os ministérios
  const ministriesToDisplay = searchTerm
    ? Object.keys(ministries).filter(ministry =>
        ministry.toLowerCase().includes(searchTerm)
      )
    : Object.keys(ministries);

  // Exibe os resultados
  if (ministriesToDisplay.length > 0) {
    ministriesToDisplay.forEach((ministry, index) => {
      const button = document.createElement("a");
      button.href = ministries[ministry];
      button.textContent = ministry;
      button.className = "btn";
      button.target = "_blank"; // Abre o link em uma nova aba
      resultsDiv.appendChild(button);

      // Adiciona a classe "show" com um pequeno atraso para criar o efeito
      setTimeout(() => {
        button.classList.add("show");
      }, index * 100); // Atraso de 100ms entre cada botão
    });
  } else {
    resultsDiv.textContent = "Nenhum ministério encontrado.";
  }
};

// Adiciona o botão "Voltar" ao corpo do documento
const createBackButton = () => {
  const backButton = document.createElement("a");
  backButton.href = "#"; // Navega para o topo ou use `javascript:history.back()` para voltar ao histórico
  backButton.className = "botao-voltar";
  backButton.textContent = "Voltar";
  backButton.addEventListener("click", (event) => {
    event.preventDefault(); // Impede o comportamento padrão
    window.history.back(); // Retorna para a página anterior
  });
  document.body.appendChild(backButton);
};

// Chama a função para criar o botão ao carregar a página
createBackButton();


// Adiciona evento para clique no botão de busca
searchButton.addEventListener("click", performSearch);

// Adiciona evento para pressionar "Enter" no campo de entrada
searchInput.addEventListener("keypress", (event) => {
  if (event.key === "Enter") {
    performSearch();
  }
});

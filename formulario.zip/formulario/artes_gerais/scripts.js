document.addEventListener('DOMContentLoaded', function () {
    // Lógica para o popup
    const popupCloseButton = document.getElementById('popup-close');
    if (popupCloseButton) {
        popupCloseButton.addEventListener('click', function () {
            const popup = document.getElementById('popup-success');
            if (popup) {
                popup.style.opacity = '0';
                setTimeout(() => popup.remove(), 300); // Suaviza o desaparecimento
            }
        });
    }

    // Lógica do formulário de seleção de versículos
    const livroSelect = document.getElementById('livro');
    const capituloSelect = document.getElementById('capitulo');
    const versiculoSelect = document.getElementById('versiculo');
    const versiculoTexto = document.getElementById('versiculo_texto');

    if (livroSelect && capituloSelect && versiculoSelect && versiculoTexto) {
        // Carregar capítulos ao selecionar o livro
        livroSelect.addEventListener('change', function () {
            const livro = this.value;
            if (livro) {
                capituloSelect.disabled = false;
                capituloSelect.innerHTML = ''; // Limpa os capítulos anteriores
                for (let i = 1; i <= 50; i++) { // Supondo 50 capítulos como padrão
                    const option = document.createElement('option');
                    option.value = i;
                    option.textContent = `Capítulo ${i}`;
                    capituloSelect.appendChild(option);
                }
            } else {
                capituloSelect.disabled = true;
                versiculoSelect.disabled = true;
                capituloSelect.innerHTML = '';
                versiculoSelect.innerHTML = '';
            }
        });

        // Carregar versículos ao selecionar o capítulo
        capituloSelect.addEventListener('change', function () {
            const livro = livroSelect.value;
            const capitulo = this.value;
            if (capitulo) {
                versiculoSelect.disabled = false;
                versiculoSelect.innerHTML = ''; // Limpa os versículos anteriores
                for (let i = 1; i <= 50; i++) { // Supondo 50 versículos como padrão
                    const option = document.createElement('option');
                    option.value = i;
                    option.textContent = `Versículo ${i}`;
                    versiculoSelect.appendChild(option);
                }
            } else {
                versiculoSelect.disabled = true;
                versiculoSelect.innerHTML = '';
            }
        });

        // Buscar o texto do versículo ao selecionar o versículo
        versiculoSelect.addEventListener('change', function () {
            const livro = livroSelect.value;
            const capitulo = capituloSelect.value;
            const versiculo = this.value;
            if (versiculo) {
                const url = `https://bible-api.com/${livro}+${capitulo}:${versiculo}`;
                fetch(url)
                    .then((response) => response.json())
                    .then((data) => {
                        if (data && data.text) {
                            versiculoTexto.value = data.text;
                        } else {
                            versiculoTexto.value = 'Texto não encontrado.';
                        }
                    })
                    .catch((error) => {
                        console.error('Erro ao carregar o versículo:', error);
                        versiculoTexto.value = 'Erro ao buscar o versículo.';
                    });
            }
        });
    }

    // Lógica para o envio de arquivos (caso precise interagir com upload de arquivos futuramente)
    const fileInput = document.getElementById('arquivo_referencia');
    if (fileInput) {
        fileInput.addEventListener('change', function () {
            const files = Array.from(this.files);
            files.forEach((file) => {
                if (file.size > 5 * 1024 * 1024) { // Limite de 5MB
                    alert(`O arquivo ${file.name} excede o tamanho máximo de 5MB.`);
                }
            });
        });
    }

    // Lógica para o campo de seleção de cores
    const colorPicker = document.getElementById('paleta_cores');
    const colorNameInput = document.getElementById('paleta_cores_nome');
    const colorCodeInput = document.getElementById('paleta_cores_codigo');

    if (colorPicker && colorNameInput && colorCodeInput) {
        colorPicker.addEventListener('input', function () {
            const colorCode = this.value;

            // Preenche o campo do código da cor
            colorCodeInput.value = colorCode;

            // Define o nome da cor (aproximação)
            fetch(`https://www.thecolorapi.com/id?hex=${colorCode.substring(1)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.name) {
                        colorNameInput.value = data.name.value; // Nome da cor
                    } else {
                        colorNameInput.value = 'Cor Desconhecida';
                    }
                })
                .catch(error => {
                    console.error('Erro ao buscar o nome da cor:', error);
                    colorNameInput.value = 'Erro ao buscar nome';
                });
        });
    }
});

<?php
// Habilitar exibição de erros para debug (remover em produção)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../vendor/autoload.php'; // Carrega o PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Coletar dados do formulário
    $nome_evento = $_POST['nome_evento'] ?? '';
    $ministerio_responsavel = $_POST['ministerio_responsavel'] ?? '';
    $responsaveis = $_POST['responsaveis'] ?? '';
    $datas_horarios = $_POST['datas_horarios'] ?? '';
    $local_evento = $_POST['local_evento'] ?? '';
    $tema = $_POST['tema'] ?? '';
    $versiculo = $_POST['versiculo'] ?? '';
    $paleta_cores = $_POST['paleta_cores'] ?? '';
    $paleta_cores_nome = $_POST['paleta_cores_nome'] ?? 'Não informado';
    $paleta_cores_codigo = $_POST['paleta_cores_codigo'] ?? 'Não informado';
    $cantores_contato = $_POST['cantores_contato'] ?? '';
    $pregadores_contato = $_POST['pregadores_contato'] ?? '';
    $instagram_cp = $_POST['instagram_cp'] ?? '';
    $aberto_igreja = $_POST['aberto_igreja'] ?? '';
    $inscricao = $_POST['inscricao'] ?? '';
    $valor_inscricao = $_POST['valor_inscricao'] ?? '';
    $responsavel_evento = $_POST['responsavel_evento'] ?? '';
    $ministerio_realizando = $_POST['ministerio_realizando'] ?? '';
    $contato_info = $_POST['contato_info'] ?? '';

    // Verificar se os campos obrigatórios estão preenchidos
    if (empty($nome_evento) || empty($responsavel_evento)) {
        die("Erro: Nome do evento e responsável pelo evento são obrigatórios.");
    }

    // Configuração do PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'martins.ryccele@gmail.com'; // Substitua pelo seu e-mail do Gmail
        $mail->Password = 'mltd yibo qxwm lcdh'; // Substitua pela senha do aplicativo
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Assunto e nome dinâmicos
        $emailAssunto = "$nome_evento - $responsavel_evento";

        // Configuração de remetente e destinatário
        $mail->setFrom('martins.ryccele@gmail.com', $emailAssunto); // Nome dinâmico no remetente
        $mail->addAddress('deislainedarling@creativemedia.com.br', 'Deislaine Darling');

        // Definir charset
        $mail->CharSet = 'UTF-8';

        // Assunto do e-mail
        $mail->Subject = $emailAssunto;

        // Corpo do e-mail
        $mail->isHTML(true);
        $mail->Body = "
            <h2>Detalhes do Evento - $nome_evento</h2>
            <p><strong>Ministério Responsável:</strong> $ministerio_responsavel</p>
            <p><strong>Responsáveis pelo Evento:</strong> $responsaveis</p>
            <p><strong>Datas e Horários:</strong> $datas_horarios</p>
            <p><strong>Local do Evento:</strong> $local_evento</p>
            <p><strong>Tema:</strong> $tema</p>
            <p><strong>Versículo Bíblico:</strong> $versiculo</p>
            <p><strong>Paleta de Cores:</strong> $paleta_cores_nome ($paleta_cores_codigo)</p>
            <div style='width: 50px; height: 50px; background-color: $paleta_cores_codigo; border: 1px solid #000;'></div>
            <p><strong>Cantores e Contato:</strong> $cantores_contato</p>
            <p><strong>Pregadores e Contato:</strong> $pregadores_contato</p>
            <p><strong>Instagram dos Cantores e Pregadores:</strong> $instagram_cp</p>
            <p><strong>Aberto a Todos da Igreja?</strong> $aberto_igreja</p>
            <p><strong>Necessário Inscrição?</strong> $inscricao</p>
            <p><strong>Valor da Inscrição:</strong> $valor_inscricao</p>
            <p><strong>Responsável pelo Evento:</strong> $responsavel_evento</p>
            <p><strong>Ministério Realizando:</strong> $ministerio_realizando</p>
            <p><strong>Telefone de Contato:</strong> $contato_info</p>
        ";

        // Processar uploads de arquivos
        if (!empty($_FILES['arquivo_referencia']['name'][0])) {
            foreach ($_FILES['arquivo_referencia']['tmp_name'] as $index => $tmpName) {
                if (is_uploaded_file($tmpName)) {
                    $fileName = $_FILES['arquivo_referencia']['name'][$index];

                    // Validar tamanho do arquivo (limite de 5MB)
                    if ($_FILES['arquivo_referencia']['size'][$index] <= 5 * 1024 * 1024) { // 5 MB
                        $mail->addAttachment($tmpName, $fileName); // Adicionar arquivo como anexo
                    } else {
                        echo "<script>alert('O arquivo $fileName excede o tamanho máximo de 5MB e não foi enviado.');</script>";
                    }
                }
            }
        }

        // Enviar e-mail
        $mail->send();

        // Exibe a mensagem de sucesso e redireciona de volta para o formulário vazio
        echo "<script>
                alert('Formulário enviado com sucesso! O Material ficará disponível para Download em até 10 dias úteis');
                window.location.href = '/formulario/artes_gerais/index.html'; // Redireciona de volta ao formulário
              </script>";
    } catch (Exception $e) {
        echo "<script>
                alert('Erro ao enviar o formulário: {$mail->ErrorInfo}');
                window.location.href = '/formulario/artes_gerais/index.html'; // Redireciona de volta ao formulário
              </script>";
    }
}
?>
